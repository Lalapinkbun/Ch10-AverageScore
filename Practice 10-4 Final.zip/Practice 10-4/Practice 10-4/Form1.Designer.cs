﻿namespace Practice_10_4
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnMath = new System.Windows.Forms.Button();
            this.txtCN = new System.Windows.Forms.TextBox();
            this.txtBM = new System.Windows.Forms.TextBox();
            this.txtEN = new System.Windows.Forms.TextBox();
            this.txtMT = new System.Windows.Forms.TextBox();
            this.txtSC = new System.Windows.Forms.TextBox();
            this.txtSJ = new System.Windows.Forms.TextBox();
            this.txtGG = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.btnWhat = new System.Windows.Forms.Button();
            this.label8 = new System.Windows.Forms.Label();
            this.txtBfianlScore = new System.Windows.Forms.RichTextBox();
            this.SuspendLayout();
            // 
            // btnMath
            // 
            this.btnMath.Location = new System.Drawing.Point(235, 39);
            this.btnMath.Name = "btnMath";
            this.btnMath.Size = new System.Drawing.Size(173, 23);
            this.btnMath.TabIndex = 0;
            this.btnMath.Text = "计算";
            this.btnMath.UseVisualStyleBackColor = true;
            this.btnMath.Click += new System.EventHandler(this.btnMath_Click);
            // 
            // txtCN
            // 
            this.txtCN.Location = new System.Drawing.Point(116, 41);
            this.txtCN.Name = "txtCN";
            this.txtCN.Size = new System.Drawing.Size(100, 20);
            this.txtCN.TabIndex = 1;
            // 
            // txtBM
            // 
            this.txtBM.Location = new System.Drawing.Point(116, 67);
            this.txtBM.Name = "txtBM";
            this.txtBM.Size = new System.Drawing.Size(100, 20);
            this.txtBM.TabIndex = 2;
            // 
            // txtEN
            // 
            this.txtEN.Location = new System.Drawing.Point(116, 93);
            this.txtEN.Name = "txtEN";
            this.txtEN.Size = new System.Drawing.Size(100, 20);
            this.txtEN.TabIndex = 3;
            // 
            // txtMT
            // 
            this.txtMT.Location = new System.Drawing.Point(116, 119);
            this.txtMT.Name = "txtMT";
            this.txtMT.Size = new System.Drawing.Size(100, 20);
            this.txtMT.TabIndex = 4;
            // 
            // txtSC
            // 
            this.txtSC.Location = new System.Drawing.Point(116, 145);
            this.txtSC.Name = "txtSC";
            this.txtSC.Size = new System.Drawing.Size(100, 20);
            this.txtSC.TabIndex = 5;
            // 
            // txtSJ
            // 
            this.txtSJ.Location = new System.Drawing.Point(116, 171);
            this.txtSJ.Name = "txtSJ";
            this.txtSJ.Size = new System.Drawing.Size(100, 20);
            this.txtSJ.TabIndex = 6;
            // 
            // txtGG
            // 
            this.txtGG.Location = new System.Drawing.Point(116, 197);
            this.txtGG.Name = "txtGG";
            this.txtGG.Size = new System.Drawing.Size(100, 20);
            this.txtGG.TabIndex = 7;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(73, 44);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(37, 13);
            this.label1.TabIndex = 8;
            this.label1.Text = "华文：";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(25, 70);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(85, 13);
            this.label2.TabIndex = 9;
            this.label2.Text = "马来文（国文）：";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(73, 96);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(37, 13);
            this.label3.TabIndex = 10;
            this.label3.Text = "英文：";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(73, 122);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(37, 13);
            this.label4.TabIndex = 11;
            this.label4.Text = "数学：";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(73, 148);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(37, 13);
            this.label5.TabIndex = 12;
            this.label5.Text = "科学：";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(73, 174);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(37, 13);
            this.label6.TabIndex = 13;
            this.label6.Text = "地理：";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(73, 200);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(37, 13);
            this.label7.TabIndex = 14;
            this.label7.Text = "历史：";
            // 
            // btnWhat
            // 
            this.btnWhat.Location = new System.Drawing.Point(12, 260);
            this.btnWhat.Name = "btnWhat";
            this.btnWhat.Size = new System.Drawing.Size(159, 35);
            this.btnWhat.TabIndex = 15;
            this.btnWhat.Text = "这是什么？";
            this.btnWhat.UseVisualStyleBackColor = true;
            this.btnWhat.Click += new System.EventHandler(this.btnWhat_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.Yellow;
            this.label8.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label8.Location = new System.Drawing.Point(171, 9);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(69, 15);
            this.label8.TabIndex = 16;
            this.label8.Text = "计算总平均";
            // 
            // txtBfianlScore
            // 
            this.txtBfianlScore.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtBfianlScore.Cursor = System.Windows.Forms.Cursors.Default;
            this.txtBfianlScore.Location = new System.Drawing.Point(235, 67);
            this.txtBfianlScore.Name = "txtBfianlScore";
            this.txtBfianlScore.Size = new System.Drawing.Size(173, 228);
            this.txtBfianlScore.TabIndex = 17;
            this.txtBfianlScore.Text = "";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Pink;
            this.ClientSize = new System.Drawing.Size(420, 307);
            this.Controls.Add(this.txtBfianlScore);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.btnWhat);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtGG);
            this.Controls.Add(this.txtSJ);
            this.Controls.Add(this.txtSC);
            this.Controls.Add(this.txtMT);
            this.Controls.Add(this.txtEN);
            this.Controls.Add(this.txtBM);
            this.Controls.Add(this.txtCN);
            this.Controls.Add(this.btnMath);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnMath;
        private System.Windows.Forms.TextBox txtCN;
        private System.Windows.Forms.TextBox txtBM;
        private System.Windows.Forms.TextBox txtEN;
        private System.Windows.Forms.TextBox txtMT;
        private System.Windows.Forms.TextBox txtSC;
        private System.Windows.Forms.TextBox txtSJ;
        private System.Windows.Forms.TextBox txtGG;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button btnWhat;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.RichTextBox txtBfianlScore;
    }
}

